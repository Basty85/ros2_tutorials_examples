settings;
reldir = "/test_sl/generate_mex";
addpath(genpath(pwd+reldir));
cd (pwd+reldir);
generate_mex;
exit(0);

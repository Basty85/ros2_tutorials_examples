#include <iostream>

#include "tq_distbn_srv.hpp"

int main()
{
    // positive
    float motion_tq_tar_total_Nm = 150.0;
    float powertrain_tq_recuperation_capacity_Nm = -25.0;

    Torque_Distribution_Service tq_distbn_srv(motion_tq_tar_total_Nm, powertrain_tq_recuperation_capacity_Nm);

    tq_distbn_srv.update();

    std::cout << "tar_total_Nm: " << motion_tq_tar_total_Nm << "; "
              << "recu_cap_Nm: " << powertrain_tq_recuperation_capacity_Nm << std::endl
              << "tq_tar_pt_Nm: " << tq_distbn_srv.get_tq_tar_pt() << std::endl
              << "tq_tar_brk_Nm: " << tq_distbn_srv.get_tq_tar_brk() << std::endl
              << std::endl;

    // negative but greater as cap
    motion_tq_tar_total_Nm = -15.0;
    powertrain_tq_recuperation_capacity_Nm = -25.0;

    tq_distbn_srv.update();

    std::cout << "tar_total_Nm: " << motion_tq_tar_total_Nm << "; "
              << "recu_cap_Nm: " << powertrain_tq_recuperation_capacity_Nm << std::endl
              << "tq_tar_pt_Nm: " << tq_distbn_srv.get_tq_tar_pt() << std::endl
              << "tq_tar_brk_Nm: " << tq_distbn_srv.get_tq_tar_brk() << std::endl
              << std::endl;

    // negative and smaller as cap
    motion_tq_tar_total_Nm = -45.0;
    powertrain_tq_recuperation_capacity_Nm = -25.0;

    tq_distbn_srv.update();

    std::cout << "tar_total_Nm: " << motion_tq_tar_total_Nm << "; "
              << "recu_cap_Nm: " << powertrain_tq_recuperation_capacity_Nm << std::endl
              << "tq_tar_pt_Nm: " << tq_distbn_srv.get_tq_tar_pt() << std::endl
              << "tq_tar_brk_Nm: " << tq_distbn_srv.get_tq_tar_brk() << std::endl;

    return 0;
}

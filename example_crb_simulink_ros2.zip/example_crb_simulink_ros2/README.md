# *Torque Distribution Service* (CRB) Example ROS 2 & Matlab/Simulink

## What is this package?

- Prototype of a generic *Torque Distribution Service* example in **C++** ([tq_distbn_srv.cpp](./src/tq_distbn_srv.cpp))
- Makefile to build *Torque Distribution Service* from source and run some small static tests ([Makefile](Makefile))
- Makefile to generate s-function target of *Torque Distribution Service* for SiL testing in Matlab/Simulink
- ROS 2 package of *Torque Distribution Service* and a composition Publisher/Subscriber node ([CMakeLists.txt](./00_ros2_ws/src/tq_distbn_pubsub/CMakeLists.txt))
- [Simulink model with *Torque Distribution Service* s-function target](test_sl/generate_mex/test_cpp_in_sl_open_loop/SiL_test_tq_distbn_srv.slx)
- [Simulink model with ROS 2 connection & co-simulation](test_sl/generate_mex/test_cpp_in_sl_open_loop/ROS2_test_tq_distbn_srv.slx)

## Prerequisites (test/target system)

- [OSD 6 (Ubuntu 20.04)](https://inside-docupedia.bosch.com/confluence/display/BSC2OSD/About+OSD)
- [ROS 2 Galactic](https://docs.ros.org/en/galactic/index.html)
- [Matlab R2021b (glnxa64)](\\bosch.com\dfsrb\DfsDE\LOC\Fe\CI\NEM\CAX_CAE\Matlab\Download\R2021b)

Not yet ported & tested on Windows platforms.

## Why is that

This repo serves as a blueprint to learn and discover new ways of developing & testing distributed & flexible deployable SW. It demonstrates with the help of a small OO C++ ASW prototype *Torque Distribution Service* how to

- Build from source with `make`
- Automatically generate SiL s-functions from OO C++ ASW sourcecode for open-/closed-loop simulation & testing purposes in Matlab/Simulink
- Create, build & run Publish/Subscribe ROS 2 packages from C++ ASW
- Setup a Matlab/Simulink <-> ROS 2 co-simulation for mocking, testing and validation purposes
- Have the whole mtc to deploy the service & to generate fast feedback in your hands enabling you to develop in an end2end fashion minimizing external dependencies and decreasing lead time

## How-to use

### Build from source & simple static test of *Torque Distribution Service*

- execute: `make` from root folder:

![Make](01_resources/make.png)

- run built executable: `build/simple_static_test`
  
![Run_Exec](01_resources/run_exec.png)

- execute: `make clean` to delete generated artifacts

### Generate s-function from source & SiL simulation (use Simulink's RTE to execute sfun)

- execute: `make sfun` from root folder:

![Make_Sfun](01_resources/make_sfun.png)

- find the compiled sfun target in: ./test_sl/generate_mex/gen_sfun/

- The Simulink model that makes use resp. tests the s-function of our prototype is located [HERE](test_sl/generate_mex/test_cpp_in_sl_open_loop/SiL_test_tq_distbn_srv.slx).

### Understand, build and run ROS 2 package with pubsub-node of *Torque Distribution Service*

The [*Torque Distribution Service* node](00_ros2_ws/src/tq_distbn_pubsub/src/tq_distbn_node.cpp) from the ROS 2 package consists of three parts. A subscriber, subscribing on topic "tq_distbn_in", a publisher publishing the topic "tq_distbn_out" and the actual business logic.

The **subscriber** has an **event-based behaviour**. Every time there is a new message being published on the topic "tq_distbn_in", the subscriber callback function receives the message and is being executed.

The **publisher** has a **time-based behaviour**. There is a ROS wall timer function that is being executed every x seconds (every 0.01 s at the moment) publishing latest data on topic "tq_distbn_out".

For the *Torque Distribution Service* [business logic](00_ros2_ws/src/tq_distbn_pubsub/src/tq_distbn_srv.cpp), we did a little simplification trick:
The [*Torque Distribution Service* node](00_ros2_ws/src/tq_distbn_pubsub/src/tq_distbn_node.cpp) instanciates an object of the business logic and executes resp. updates it regularly in the subscriber callback. This means every time a new message is being received on the topic "tq_distbn_in", the business logic *Torque Distribution Service* updates it's API (output variables) as well. Because the node class holds it's own instance of the business logic, the publisher has access to the business logic output values.

ROS 2 facilitates the scheduling and messaging of the subscriber and publisher node for us (soft/hard RT requirements assume an underlying RT-OS such as a Linux dist. + Preempt-RT patch or QNX and equivalent).

Once ROS 2 has been [installed and setup](https://docs.ros.org/en/galactic/Installation/Ubuntu-Install-Debians.html) correctly on your system, you can build and let run the *Torque Distribution Service* prototype via:

- open a new terminal and `cd 00_ros2_ws`
- source ROS 2: `source /opt/ros/galactic/setup.bash`
- colcon build *tq_distbn_pubsub* package: `colcon build --packages-select tq_distbn_pubsub`

![Colcon_build](01_resources/colcon_build.png)

- open a new terminal and `cd 00_ros2_ws`
- source ROS 2 underlay: `source /opt/ros/galactic/setup.bash`
- source ROS 2 workspace overlay: `source install/setup.bash`
- Run the node: `ros2 run tq_distbn_pubsub tq_distbn_node`

![Ros2_run](01_resources/ros2_run.png)

**Congratulations**, you made it. *Torque Distribution Service* is running if you see the above screen with *"tq_tar_pt:0  tq_tar_brk:0"*! The simple reason why we see only zeros so far is the fact that no one publishes data on our subscription topic "tq_distbn_in". If the input data is all zeros, the business logic (*Torque Distribution Service*) output is all zeros as well.

To start a simple "tq_distbn_in" mockup, run the following commands in a new terminal window:

- `cd 00_ros2_ws`
- `source /opt/ros/galactic/setup.bash`
- `source install/setup.bash`
- `ros2 run tq_distbn_pubsub tq_distbn_input_provider_publisher`

![Ros2_run_input](01_resources/ros2_run_input_provider.png)

To visually inspect the signal flow of your distributed system, open a third terminal window and run:

- `source /opt/ros/galactic/setup.bash`
- `rqt`

![Rqt](01_resources/rqt_plot_and_graph.png)

- Plugins -> Introspection -> Node Graph
- Plugins -> Visualization -> Plot

### Use Simulink to communicate with ROS 2 network via built-in library to send (publish) and receive (subscribe) ROS 2 topics

tbd

#pragma once

class Torque_Distribution_Service
{
public:
    Torque_Distribution_Service(const float &ext_motion_tq_tar_total_Nm,
                                const float &ext_powertrain_tq_recuperation_capacity_Nm);

    inline float get_tq_tar_pt() { return tq_distbn_srv_tq_tar_pt_Nm; }
    inline const float &get_tq_tar_pt() const { return tq_distbn_srv_tq_tar_pt_Nm; }

    inline float get_tq_tar_brk() { return tq_distbn_srv_tq_tar_brk_Nm; }
    inline const float &get_tq_tar_brk() const { return tq_distbn_srv_tq_tar_brk_Nm; }

    void update();

private:
    float limit_tq_recu_capacity();
    bool total_greater_recu_capacity();

    const float &motion_tq_tar_total_Nm;
    const float &powertrain_tq_recuperation_capacity_Nm;

    float tq_distbn_srv_tq_tar_pt_Nm;
    float tq_distbn_srv_tq_tar_brk_Nm;
};

#pragma once

#include "geometry_msgs/msg/point.hpp"
#include "rclcpp/rclcpp.hpp"
#include "tq_distbn_srv.hpp"

class Tq_Distbn_Node : public rclcpp::Node
{
public:
    Tq_Distbn_Node();

private:
    bool tq_distbn_in_callback(const geometry_msgs::msg::Point::SharedPtr msg);

    Torque_Distribution_Service tq_distbn_srv;  // business logic instance

    float motion_tq_tar_total_Nm;
    float powertrain_tq_recuperation_capacity_Nm;

    float tq_tar_pt_Nm;
    float tq_tar_brk_Nm;

    rclcpp::TimerBase::SharedPtr timer_;
    rclcpp::Publisher<geometry_msgs::msg::Point>::SharedPtr tq_distbn_srv_pub_;
    rclcpp::Subscription<geometry_msgs::msg::Point>::SharedPtr tq_distbn_srv_sub_;
};

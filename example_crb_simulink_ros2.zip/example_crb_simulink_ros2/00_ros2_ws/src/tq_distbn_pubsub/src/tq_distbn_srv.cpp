#include "tq_distbn_pubsub/tq_distbn_srv.hpp"

#include <algorithm>

Torque_Distribution_Service::Torque_Distribution_Service(const float &ext_motion_tq_tar_total_Nm,
                                                         const float &ext_powertrain_tq_recuperation_capacity_Nm)

    :

      motion_tq_tar_total_Nm(ext_motion_tq_tar_total_Nm),
      powertrain_tq_recuperation_capacity_Nm(ext_powertrain_tq_recuperation_capacity_Nm),

      tq_distbn_srv_tq_tar_pt_Nm(0.0),
      tq_distbn_srv_tq_tar_brk_Nm(0.0)

{
}

void Torque_Distribution_Service::update()
{
    if (total_greater_recu_capacity())
    {
        tq_distbn_srv_tq_tar_pt_Nm = motion_tq_tar_total_Nm;
        tq_distbn_srv_tq_tar_brk_Nm = 0.0;
    }
    else  // tq split path
    {
        tq_distbn_srv_tq_tar_pt_Nm = limit_tq_recu_capacity();
        tq_distbn_srv_tq_tar_brk_Nm = motion_tq_tar_total_Nm - limit_tq_recu_capacity();
    }
}

bool Torque_Distribution_Service::total_greater_recu_capacity()
{
    return (motion_tq_tar_total_Nm >= limit_tq_recu_capacity());
}

float Torque_Distribution_Service::limit_tq_recu_capacity()
{
    return (std::min(powertrain_tq_recuperation_capacity_Nm, 0.0f));
}

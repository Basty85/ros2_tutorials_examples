#include "tq_distbn_pubsub/tq_distbn_node.hpp"

using namespace std::chrono_literals;

Tq_Distbn_Node::Tq_Distbn_Node()

    :

      Node("tq_distbn_node"),
      tq_distbn_srv(motion_tq_tar_total_Nm, powertrain_tq_recuperation_capacity_Nm),

      motion_tq_tar_total_Nm(0.0),
      powertrain_tq_recuperation_capacity_Nm(0.0),

      tq_tar_pt_Nm(0.0),
      tq_tar_brk_Nm(0.0)

{
    RCLCPP_INFO(this->get_logger(), "Starting Torque Distribution Service with node name %s",
                this->get_node_names()[0].c_str());

    rclcpp::QoS qos(rclcpp::KeepLast(100), rmw_qos_profile_default);

    // subscribe
    tq_distbn_srv_sub_ = this->create_subscription<geometry_msgs::msg::Point>(
        "tq_distbn_in", qos, std::bind(&Tq_Distbn_Node::tq_distbn_in_callback, this, std::placeholders::_1));

    // publish
    tq_distbn_srv_pub_ = this->create_publisher<geometry_msgs::msg::Point>("tq_distbn_out", qos);

    auto publish_msg = [this]() -> void
    {
        auto message = geometry_msgs::msg::Point();

        message.x = tq_distbn_srv.get_tq_tar_pt();
        message.y = tq_distbn_srv.get_tq_tar_brk();
        message.z = 0.0;

        std::cout << "tq_tar_pt:" << message.x << "  tq_tar_brk:" << message.y << std::endl;

        this->tq_distbn_srv_pub_->publish(message);
    };
    constexpr auto timer_dt = 10ms;
    timer_ = this->create_wall_timer(timer_dt, publish_msg);
}

bool Tq_Distbn_Node::tq_distbn_in_callback(const geometry_msgs::msg::Point::SharedPtr msg)
{
    RCLCPP_INFO(this->get_logger(), "motion_tq_tar_total_Nm: '%f' powertrain_tq_recuperation_capacity_Nm: '%f'", msg->x,
                msg->y);

    motion_tq_tar_total_Nm = msg->x;
    powertrain_tq_recuperation_capacity_Nm = msg->y;
    tq_distbn_srv.update();

    return true;
}

int main(int argc, char* argv[])
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<Tq_Distbn_Node>());
    rclcpp::shutdown();
    return 0;
}

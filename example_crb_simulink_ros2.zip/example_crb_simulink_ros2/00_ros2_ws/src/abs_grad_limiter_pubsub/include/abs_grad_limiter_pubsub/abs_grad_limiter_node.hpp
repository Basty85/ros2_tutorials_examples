#pragma once

#include "geometry_msgs/msg/point.hpp"
#include "rclcpp/rclcpp.hpp"
#include "limiter_srv.hpp"

class Limiter_Node : public rclcpp::Node
{
public:
    Limiter_Node();

private:
    bool tq_distbn_out_callback(const geometry_msgs::msg::Point::SharedPtr msg);

    Limiter limiter_srv;  // business logic instance

    float input;
    float output;
    
    float sample_time_s;
    float absolute_max;
    float absolute_min;
    float gradient_max;
    float gradient_min;

    rclcpp::TimerBase::SharedPtr timer_;
    rclcpp::Publisher<geometry_msgs::msg::Point>::SharedPtr limiter_srv_pub_;
    rclcpp::Subscription<geometry_msgs::msg::Point>::SharedPtr limiter_srv_sub_;
};

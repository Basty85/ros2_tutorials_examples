#pragma once

class Limiter
{
public:
    Limiter(const float &init_sample_time_s, const float &init_absolute_max_val, const float &init_absolute_min_val,
            const float &init_gradient_max_val, const float &init_gradient_min_val);

    float update(float input);

private:
    float absolute_limitation(float input);
    float gradient_limitation(float input);

    // data members
    const float &sample_time_s;
    const float &absolute_max_val;
    const float &absolute_min_val;
    const float &gradient_max_val;
    const float &gradient_min_val;

    bool is_first_cycle_1;

    float input_K1;
    float absolute_limit_output;
    float gradient_limit_output;
    float output;
};

#include "abs_grad_limiter_pubsub/limiter_srv.hpp"

Limiter::Limiter(const float &init_sample_time_s, const float &init_absolute_max_val,
                 const float &init_absolute_min_val, const float &init_gradient_max_val,
                 const float &init_gradient_min_val)

    :

      sample_time_s(init_sample_time_s),
      absolute_max_val(init_absolute_max_val),
      absolute_min_val(init_absolute_min_val),
      gradient_max_val(init_gradient_max_val),
      gradient_min_val(init_gradient_min_val),

      is_first_cycle_1(true),

      input_K1(0.0),
      absolute_limit_output(0.0),
      gradient_limit_output(0.0),
      output(0.0)
{
}

float Limiter::update(float input)
{
    absolute_limit_output = absolute_limitation(input);
    output = gradient_limitation(absolute_limit_output);
    return output;
}

float Limiter::absolute_limitation(float input)
{  // consider assertion if max < min val

    if (input > absolute_max_val)
        return absolute_max_val;
    else if (input < absolute_min_val)
        return absolute_min_val;
    else
        return (absolute_limit_output = input);
}

float Limiter::gradient_limitation(float input)
{  // consider assertion if max < min val param
    if (is_first_cycle_1)
    {
        input_K1 = input;
        is_first_cycle_1 = false;
    }

    float gradient = (input - input_K1) / sample_time_s;

    if (gradient > gradient_max_val)
        gradient_limit_output = (input_K1 + gradient_max_val * sample_time_s);
    else if (gradient < gradient_min_val)
        gradient_limit_output = (input_K1 + gradient_min_val * sample_time_s);
    else
        gradient_limit_output = (input_K1 + gradient * sample_time_s);

    input_K1 = gradient_limit_output;

    return gradient_limit_output;
}

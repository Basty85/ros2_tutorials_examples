#include "abs_grad_limiter_pubsub/abs_grad_limiter_node.hpp"

using namespace std::chrono_literals;

Limiter_Node::Limiter_Node()

    :

      Node("limiter_node"),
      limiter_srv(sample_time_s, absolute_max, absolute_min, gradient_max, gradient_min),

      input(0.0),
      output(0.0),
      sample_time_s(0.01),
      absolute_max(100),
      absolute_min(-100000),
      gradient_max(100000),
      gradient_min(-100000)
{
    RCLCPP_INFO(this->get_logger(), "Starting Limiter Service with node name %s", this->get_node_names()[0].c_str());

    rclcpp::QoS qos(rclcpp::KeepLast(100), rmw_qos_profile_default);

    // subscribe
    limiter_srv_sub_ = this->create_subscription<geometry_msgs::msg::Point>(
        "tq_distbn_out", qos, std::bind(&Limiter_Node::tq_distbn_out_callback, this, std::placeholders::_1));

    // publish
    limiter_srv_pub_ = this->create_publisher<geometry_msgs::msg::Point>("limiter_out", qos);

    auto publish_msg = [this]() -> void
    {
        auto message = geometry_msgs::msg::Point();

        message.x = limiter_srv.update(input);
        message.y = 0.0;
        message.z = 0.0;

        std::cout << "limiter_output:" << message.x << std::endl;

        this->limiter_srv_pub_->publish(message);
    };
    constexpr auto timer_dt = 10ms;
    timer_ = this->create_wall_timer(timer_dt, publish_msg);
}

bool Limiter_Node::tq_distbn_out_callback(const geometry_msgs::msg::Point::SharedPtr msg)
{
    RCLCPP_INFO(this->get_logger(), "input: '%f' ", msg->x);

    input = msg->x;

    return true;
}

int main(int argc, char* argv[])
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<Limiter_Node>());
    rclcpp::shutdown();
    return 0;
}

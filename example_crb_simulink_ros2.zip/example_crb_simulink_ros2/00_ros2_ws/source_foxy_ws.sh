#!/bin/bash

export RMW_IMPLEMENTATION=rmw_cyclonedds_cpp
# export RMW_IMPLEMENTATION=rmw_fastrtps_cpp
# export ROS_DOMAIN_ID=0
export CYCLONEDDS_URI=file:///home/dis3si/repos/example_crb_simulink_ros2/00_ros2_ws/cyclonedds.xml

source /opt/ros/foxy/setup.bash
#source /opt/ros/galactic/setup.bash
source install/setup.bash
#source install/perception_kit_visu/share/perception_kit_visu/local_setup.bash
#source install/perception_kit_msgs/share/perception_kit_msgs/local_setup.bash
